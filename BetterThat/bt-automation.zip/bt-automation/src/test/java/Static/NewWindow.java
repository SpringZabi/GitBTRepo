package Static;

import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import generic.CommonBaseTest;
import page.BtHomepage;

public class NewWindow extends CommonBaseTest {
	@Test
	public void CreateNewTab() throws InterruptedException {
		BtHomepage bhp = new BtHomepage(driver);
		Thread.sleep(1000);
		((JavascriptExecutor) driver).executeScript("window.open();");
		driver.get("uat.betterthat.shop");
		Thread.sleep(5000);
		Set<String> windows = driver.getWindowHandles();
		for (String name : windows) {
			System.out.println(name);
			
		}
		
	}

}
