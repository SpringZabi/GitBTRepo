package Static;

import java.time.Duration;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Set;

import javax.swing.text.Element;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import freemarker.core.JavaScriptOutputFormat;
import generic.CommonBaseTest;
import page.BackendDashBoardPage;
import page.BackendLoginPage;
import page.BackendRetailerDropAuctionPage;
import page.BackendRetailersProductsPage;
import page.BtHomepage;
import page.CheckOutPage;
import page.DropAuctionPage;
import page.DropAuctionProductDetailsPage;
import page.DropAuctionRoomPage;
import page.MultiRetailerGridPage;
import page.ScheduleDropAuctionPage;
import page.SignInPage;

public class ScheduleDropAuction extends CommonBaseTest {
	@Test
	public void DropAuction() throws Throwable {
		BtHomepage bhp = new BtHomepage(driver);
		BackendLoginPage blp = new BackendLoginPage(driver);
		BackendDashBoardPage bdbp = new BackendDashBoardPage(driver);
		BackendRetailerDropAuctionPage brdp = new BackendRetailerDropAuctionPage(driver);
		BackendRetailersProductsPage brpp = new BackendRetailersProductsPage(driver);
		ScheduleDropAuctionPage sdap = new ScheduleDropAuctionPage(driver);
		MultiRetailerGridPage mrp = new MultiRetailerGridPage(driver);
		DropAuctionPage dap = new DropAuctionPage(driver);
		DropAuctionProductDetailsPage dapdp = new DropAuctionProductDetailsPage(driver);
		CheckOutPage cop = new CheckOutPage(driver);
		SignInPage sip = new SignInPage(driver);
		DropAuctionRoomPage darp = new DropAuctionRoomPage(driver);

		Thread.sleep(2000);
		((JavascriptExecutor) driver).executeScript("window.open();");
		Thread.sleep(2000);
		//System.out.println(driver.getWindowHandles().size());
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		Thread.sleep(2000);
		driver.get("https://dev.betterthat.shop/login");
		Thread.sleep(2000);
		blp.enterBackendEmail("sreeja+admin@springdigital.com.au");
		blp.enterBackendPw("Sreeja@123");
		blp.loginBtnClick();
		Thread.sleep(3000);
		bdbp.DropAuction();
		Thread.sleep(2000);
		brdp.ScheduleDrop();
		Thread.sleep(2000);
		brpp.SelectRetailerField();
		Thread.sleep(2000);
		
		brpp.InputRetaileFld("JStore");
		Thread.sleep(2000);
		//brpp.ProductNameTextFld("Ladies Hand Bag");
		String pass = brpp.ProductNameTextFld("Ladies Hand Bag");
		Thread.sleep(3000);
		brpp.ActionsBtn();
		Thread.sleep(3000);
		brpp.ScheduleDropAuctionbtn();
		Thread.sleep(2000);
		sdap.FeaturedDropAuction();
		Thread.sleep(2000);
		sdap.DropAuctionDate();
		Thread.sleep(2000);
		sdap.DateSelected ();
		Thread.sleep(2000);
		sdap.DropAuction24HrsFormat();
		Thread.sleep(2000);

		// Define the time zone for Sydney
        ZoneId sydneyZone = ZoneId.of("Australia/Sydney");

        // Get the current time in Sydney
        ZonedDateTime sydneyTime = ZonedDateTime.now(sydneyZone);
        int hours=sydneyTime.getHour();
        System.out.println(hours);
        String hrs = Integer.toString(hours);
        
        // Define the date and time format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        
        // Format and print the Sydney time
        String formattedTime = sydneyTime.format(formatter);
        System.out.println("Current time in Sydney: " + formattedTime);
		
        sdap.getDropAuction24hrsFormatTextField().sendKeys(hrs);
		sdap.getDropAuction24hrsFormatTextField().sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
		int minutesToAdd = 2;
		
		int minute = sydneyTime.getMinute() + minutesToAdd ;
		if (minute % 2 != 0) {
			minute++; 
			
		}
		
		String min = sydneyTime.withMinute(minute).format(formatter);
		System.out.println(min);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,100)", "");
		sdap.getDropAuctionAvailableSlotField().click();
		sdap.getDropAuctionAvailableSlotTextField().sendKeys(min);
		sdap.getDropAuctionAvailableSlotTextField().sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
		sdap.ScheduleAuctionBtn();
		Thread.sleep(500);

		String confirmation = sdap.PopUpMessage();
		if (confirmation.contains("Success")) {
			System.out.println("The Product is added to the Drop auction ");
			extentTest.log(Status.PASS, "The Product is Added to the DropAuction");
		}
		else {
			System.out.println("The Product is  not added to the Drop auction ");
			extentTest.log(Status.FAIL, "The Product is  not Added to the DropAuction");
		}

		bdbp.DropAuction();
		Thread.sleep(2000);
		brdp.ProducName();
		Thread.sleep(4000);
		
		
		/*
		 String pdName = brdp.ProducName();
		if (pass.equals(pdName)) {
			System.out.println("The Product Added to The Drop Auction is Same");

		}
		else {
			System.out.println("The Product Added to the Drop Auction is  not Same");
		}
		 */
		
		driver.switchTo().window(tabs.get(0));
		
		Thread.sleep(2000);
		mrp.popUpCloseButton();
		Thread.sleep(2000);
		bhp.DropAuctionBtn();
		Thread.sleep(2000);
		dap.ScrollUntilTheElement(driver);
		Thread.sleep(2000);
		dap.ProductImage();
		Thread.sleep(2000);
		//scrollBarAction(driver);
		js.executeScript("window.scrollTo(0,700)", "");
		Thread.sleep(2000);
		dapdp.AttributeSelection();
		Thread.sleep(2000);
		//dapdp.MaterailAtt();
		//Thread.sleep(2000);
		dapdp.JoinTheDrop();

		Thread.sleep(4000);
		cop.clickLoginBtn();

		String signInmail = "jisha@springdigital.com.au";
		String signInPassword ="Bt@2023";
		sip.enterSingInEmail(signInmail);
		extentTest.log(Status.INFO, "SinginEmail Entered:  "+signInmail);
		sip.enterSingInPwd(signInPassword);
		extentTest.log(Status.INFO, "Password:  "+"*******");
		sip.btnClick();

		js.executeScript("window .scrollTo(0,600)", "");
		//scrollBarAction(driver);
		cop.NameInCard();
		driver.switchTo().frame(cop.getCardNoFrameText());
		cop.CardNoField();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(cop.getExpFrameText());
		cop.ExpireDateFld();
		driver.switchTo().defaultContent();
		driver.switchTo().frame(cop.getCVVFrameText());
		cop.CVVField();
		driver.switchTo().defaultContent();
		//Thread.sleep(3000);
		js.executeScript("window .scrollTo(0,600)", "");
		//scrollBarAction(driver);
		Thread.sleep(3000);
		cop.AddPaymentBtn();
		Thread.sleep(3000);
		/*
		js.executeScript("window .scrollTo(0,-600)", "");
		Thread.sleep(3000);
		cop.DeliveryOptions();
		Thread.sleep(3000);
		*/
		cop.DobTextFld();
		js.executeScript("window .scrollTo(0,100)", "");
		Thread.sleep(3000);
		cop.SelectYearDrpDwn();
		Thread.sleep(3000);
		cop.DobCheckBox();
		Thread.sleep(1000);
		cop.ChangeOfMindCheckBox();
		Thread.sleep(1000);
		cop.JoinTheDropBtn();
		Thread.sleep(5000);
		
		//Thread.sleep(1*60*1000);
	//WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(120));
		wait.until(ExpectedConditions.elementToBeClickable(darp.getBuyNowBtn())).click();
		//WebElement ele = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='dropAuctionProduct_bidBtnBox__czeKK']//span")));
		//ele.click();
		//darp.WaitAndClick();
		Thread.sleep(5000);
		//sdap.ClickOnYesAfterSchedule();
		//Thread.sleep(4000);
		//sdap.CloseBtn();



	}
}
