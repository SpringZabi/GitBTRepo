package Static;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import generic.CommonBaseTest;

import page.AddtoBagePage;
import page.BtHomepage;
import page.CategoryPopUpPage;
import page.CheckOutGuestPage;
import page.MultiRetailerGridPage;
import page.WhislistPage;

public class VerifyingTheProductNameandPriceOnCheckOut extends CommonBaseTest {
	@Test(priority = 21)
	public void ValiadtePricaAndNameOnCheckout() throws Throwable {
		BtHomepage bhp = new BtHomepage(driver);
		CategoryPopUpPage cpp = new CategoryPopUpPage(driver);
		MultiRetailerGridPage mrp = new MultiRetailerGridPage(driver);
		AddtoBagePage atb = new AddtoBagePage(driver);
		CheckOutGuestPage cogp = new CheckOutGuestPage(driver);

		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", bhp.getLastElementOfPage());
		Thread.sleep(3000);
		bhp.SelectTheCountry();
		Thread.sleep(2000);
		bhp.BetterThatImg();
		Thread.sleep(2000);
		bhp.CategoryBtn();
		Thread.sleep(2000);
		cpp.ViewAllBtn();
		Thread.sleep(4000);

		mrp.BreadCum();//naviagted to MultiReatiler Grid page through Category
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window .scrollTo(0,600)", "");
		//scrollBarAction(driver);
		//String productNameOnGridPage = mrp.getGridProduct_name();
		//String productPriceOnGridPage = mrp.getGridProduct_Price();
		mrp.popUpCloseButton();
		
		
		WebElement ele = driver.findElement(By.xpath("//div[@class='listing_productImage__dR7Sj']/span/img"));
		Actions action = new Actions(driver);
		action.moveToElement(ele).perform();
		Thread.sleep(3000);

		mrp.clickAddtoBagBtn();
		Thread.sleep(2000);

		String productNameOnGridPage = atb.ProductName();
		String productPriceOnGridPage = atb.ProductPrice();
		Thread.sleep(2000);
		
		atb.clickATBPopUpBtn();
		//Thread.sleep(2000);
		extentTest.log(Status.PASS, "Test pass: Item added to cart successfully");
		Thread.sleep(2000);
		
		bhp.CheckOutBtn();
		Thread.sleep(4000);

		String productNameOnCheckoputPage = cogp.ProductNameOnCheckoutasGuest();
		if (productNameOnGridPage==(productNameOnCheckoputPage)) {
			System.out.println("The Product Name is same on both GridPage and Checkout Page");
			extentTest.log(Status.PASS , "The Product name is Same on Both The Pages");
		}
		else {
			System.out.println("The Product Name is different on both GridPage and Checkout Page");
			extentTest.log(Status.PASS , "The Product name is different on Both The Pages");
		}

		String produtcPriceOnCheckoutPage = cogp.productPriceOnCheckoutasGuest();
		if (productPriceOnGridPage.equals(produtcPriceOnCheckoutPage)) {
			System.out.println("The Product Price is same on both GridPage and Checkout Page");
			extentTest.log(Status.PASS , "The Product price is Same on Both The Pages");
		}
		else {
			System.out.println("The Product Price is different on both GridPage and Checkout Page");
			extentTest.log(Status.PASS , "The Product price is different on Both The Pages");
		}
		
	}
}
