package page;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import generic.CommonBaseTest;
import generic.WebDriverUtility;

public class CheckOutGuestPage extends CommonBaseTest   {
	public WebDriver driver;
	
	@FindBy(xpath = "//input[@name='name']")
	private WebElement FirstNameTxtFld;

	@FindBy(xpath = "//input[@name='lname']") 
	private WebElement LastNameTxtFld;

	@FindBy(xpath = "//input[@name='email']")
	private WebElement EmailTxtFld;

	@FindBy(xpath = "//input[@name='phoneNumber']")
	private WebElement PhoneNoTxtFld;

	@FindBy(xpath = "//span[text()='Process to Proceed']") 
	private WebElement ProceedCheckoutBtn;

	@FindBy(xpath = "//label[text()='I agree to the ']")
	private WebElement CheckBox;

	@FindBy(xpath = "//span[@class='checkout_bagsItemTitle__edkbz']/a")
	private WebElement productNameOnCheckoutasGuest;

	@FindBy(xpath = "//span[@class='checkout_bagsItemPrice__5t5dZ']")
	private WebElement productPriceOnCheckoutasGuest;

	WebDriverUtility webDriverUtility=new WebDriverUtility();
	public CheckOutGuestPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public String ProductNameOnCheckoutasGuest() {
		String name = productNameOnCheckoutasGuest.getText();
		System.out.println("Product Name on CheckOutPage :-"+name);
		return name;
	}

	public String productPriceOnCheckoutasGuest() {
		String price = productPriceOnCheckoutasGuest.getText();
		System.out.println("Prooduct Price on CheckOutPage :-"+price);
		return price;
	}
	public WebElement getFirstNameTxtFld() {
		return FirstNameTxtFld;
	}


	public WebElement getLastNameTxtFld() {
		return LastNameTxtFld;
	}


	public WebElement getEmailTxtFld() {
		return EmailTxtFld;
	}


	public WebElement getPhoneNoTxtFld() {
		return PhoneNoTxtFld;
	}


	public WebElement getProceedCheckoutBtn() {
		return ProceedCheckoutBtn;
	}


	public WebElement getCheckBox() {
		return CheckBox;
	}

	public void FirstTextFld() {
		FirstNameTxtFld.sendKeys("Jisha");
	}

	public void LastTextFld() {
		LastNameTxtFld.sendKeys("jayaram");
	}

	public void EmailTextFld() {
		EmailTxtFld.sendKeys("jishajayaram@yopmail.com");
	}

	public void PhoneNoTextFld() {
		PhoneNoTxtFld.clear();
		PhoneNoTxtFld.sendKeys("650868");
	}

	public void CheckBox() {
		CheckBox.click();
	}
	public void ProceedcheckOutBtn() {
		ProceedCheckoutBtn.click();
	}

	public void FillTheDetails() throws Throwable {
		Thread.sleep(3000);
		FirstNameTxtFld.sendKeys("jisha");
		LastNameTxtFld.sendKeys("jayaram");
		EmailTxtFld.sendKeys("jisha@yopmail.com");
		PhoneNoTxtFld.sendKeys("657894");
		Thread.sleep(2000);
		//webDriverUtility.scrollBarAction(driver);
		CheckBox.click();
		webDriverUtility.scrollAndClickElement(driver, ProceedCheckoutBtn);
		//wait.until(ExpectedConditions.elementToBeClickable(ProceedCheckoutBtn)).click();
		//ProceedCheckoutBtn.click();

	}
}
