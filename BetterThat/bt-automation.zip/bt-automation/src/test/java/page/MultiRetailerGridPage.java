/**
 * 
 */
package page;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author shaik
 *
 */
public class MultiRetailerGridPage  {
	public WebElement getFirst_Product() {
		return first_Product;
	}


	public WebElement getViewMoreBtn() {
		return viewMoreBtn;
	}


	public WebElement getBreadcrumbsparent() {
		return breadcrumbsparent;
	}


	public WebElement getSignUpPopUp() {
		return signUpPopUp;
	}


	//Initilization
	WebDriver driver;
	public MultiRetailerGridPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}


	//@FindBy(xpath = "//div[@class='customCol false']") private WebElement productgrid;
	
	@FindBy(xpath = "(//div[@class='customCol false']//img[@alt='heart'])[1]")
	private WebElement firstHeart;
	
	@FindBy(xpath = "//div[@class='listing_productImage__dR7Sj']/span/img") 
	private WebElement first_Product;
	
	@FindBy(xpath ="//div[@class='listing_listingCardInner__LwnDd']//h3" )
	private WebElement GridProduct_name;
	
	@FindBy(xpath = "//div[@class='modal-content RegisterLogin_removePadding__jhYc2 RegisterLogin_modalContent__72Mzt']//button[@class='close']")
	private WebElement popUpCloseBtn;
	
	@FindBy(xpath = "//div[@class='container']//ul[contains(@class,'breadcums listing')]//li") 
	private WebElement BreadCrum;
	
	@FindBy(xpath = "//button[.='Add to Bag']")
	private WebElement AddtoBagBtn ;
	
	@FindBy(xpath = "//div[@class='listing_heading__vnuhY']//b")
	private WebElement breadCumBySearch;
	
	@FindBy(xpath = "(//div[@class='listing_mainPrice__HXoxo']//span/span)[2]")
	private WebElement gridProduct_Price;
	
	@FindBy(xpath = "//button[.='View More']")
	private WebElement viewMoreBtn;
	
	@FindBy(xpath ="//div[@class='container']/ul/li[2]")
	private WebElement bredcrumbsmaster;  
	
	@FindBy(xpath ="//div[@class='container']/ul/li[3]")
	private WebElement breadcrumbsparent;
	
	@FindBy(xpath = "//div[@class = 'listing_listingCardInfo__5JhvL']/h3")
	private WebElement gridProductname;
	
	@FindBy(xpath = "//h2[text()='Sign up']")
	public WebElement signUpPopUp;
	

	

	public WebElement getBreadCumBySearch() {
		return breadCumBySearch;
	}


	public WebElement getAddtoBagBtn() {
		return AddtoBagBtn;
	}

	public void clickAddtoBagBtn() {
		AddtoBagBtn.click();
	}

	public void setAddtoBagBtn(WebElement addtoBagBtn) {
		AddtoBagBtn = addtoBagBtn;
	}

	//button[@class='listing_btnCustom__cbLGx listing_btn_type1__kSMy2']
	public WebElement getBreadCrum() {
		return BreadCrum;
	}

	public WebElement addWishlist() {
		return firstHeart;
	}

	public void ViewMoreBtn() {
		viewMoreBtn.click();
	}
	public void popUpCloseButton() {
		try {
			popUpCloseBtn.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}

	}

	//Category grid breadcrumbs
	public String getBredcrumbsmaster() 
	{
		String breadcrumbsmastertxt = (bredcrumbsmaster.getText()).toLowerCase();

		return breadcrumbsmastertxt;
	}


	public String getBredcrumbsparent() 
	{
		String breadcrumbsparenttxt = (breadcrumbsparent.getText()).toLowerCase();
		return breadcrumbsparenttxt;
	}

	//Moving to fist product
	public WebElement getFirst_Product(WebDriver driver) throws Throwable {
		Actions actions = new Actions(driver);
		actions.moveToElement(first_Product).perform();  
		Thread.sleep(2000);
		return first_Product;
	}
	public void MouseHoverOnElement() {
		
	}
	public void ClickOnWishListIcon() throws InterruptedException {
		//		String nameOnMultiRetailerPage = gridProductName.getText();
		//		System.out.println(nameOnMultiRetailerPage);
		firstHeart.click();
		Thread.sleep(2000);
		
		try {
			if (signUpPopUp.isDisplayed()) {
				popUpCloseBtn.click();
			}
		} catch (Exception e) {
			//e.printStackTrace();
		}
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getFirstHeart() {
		return firstHeart;
	}

	public String getGridProduct_name() {
		String nameOnMultiRetailerPage = GridProduct_name.getText();
		//System.out.println("Product Name on the MultiRetailer Grid Page :- " + nameOnMultiRetailerPage);

		/*
		try {
			if (nameOnMultiRetailerPage.contains("...")==true) {
				nameOnMultiRetailerPage = nameOnMultiRetailerPage.replaceAll("[^a-zA-Z0-9]", " ");
				nameOnMultiRetailerPage = nameOnMultiRetailerPage.trim();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
*/
		return nameOnMultiRetailerPage;
	}
	
	public String getGridProduct_Price() {
		String priceOnMultiRetailerPage =gridProduct_Price.getText();
		System.out.println("Product Price on the MultiRetailer Grid Page :- " + priceOnMultiRetailerPage);
		return priceOnMultiRetailerPage;
	}

	public void BreadCum() throws Throwable {
		String value = BreadCrum.getText();
		//System.out.println(value);
		Thread.sleep(1000);
		if (value.contains("Home")) {
			System.out.println("The user is on the MultiRetailer Category Grid page");
		}
		else {
			System.out.println("The user is not on the MultiRetailer Category Grid page");

		}
	}
	public void BreadCumBySearch() {
		String value = breadCumBySearch.getText();
		if (value.contains("toys")) {
			System.out.println("The user is on the Particular search Grid page");
		}
		else {
			System.out.println("The user is on the different page");
		}
	}
	public WebElement getPopUpCloseBtn() {
		return popUpCloseBtn;
	}

	//Getting first product name     
    public String getGridProductname() {
       String grid_Prod_Name = gridProductname.getText();
       //System.out.println("The first product in the grid page and added to cart is : "+grid_Prod_Name);
       return grid_Prod_Name;
   }

}
